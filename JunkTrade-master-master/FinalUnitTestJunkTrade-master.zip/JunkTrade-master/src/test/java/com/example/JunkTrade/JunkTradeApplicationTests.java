package com.example.JunkTrade;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JunkTradeApplicationTests {

	@Test
	void contextLoads() {
	}

}
