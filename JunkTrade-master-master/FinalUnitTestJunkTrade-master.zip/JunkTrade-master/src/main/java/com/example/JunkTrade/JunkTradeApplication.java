package com.example.JunkTrade;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JunkTradeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JunkTradeApplication.class, args);
	}

}
